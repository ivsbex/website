# website
Black Earth X website

English
1. Unpack archive to path, where saved all your downloaded files
2. Rename unpacked folder to website (First small letter)
#Now to open website write "file://path"
#On Android phones: file:///sdcard/Download/website/main.html
           OR
1. Install Termux
2. Install git
3. Write git clone https://github.com/ivsbex/website

Русский
1. Распакуйте архив туда, где сохраняются скачанные файлы
2. Переименуйте распакованную папку в website (Первая буква маленькая)
#Для того, чтобы открыть веб-сайт напишите "file://путь"
#На Андроид телефонах: file:///sdcard/Download/website/main.html
         ИЛИ
1. Установите Termux
2. Установите git
3. Напишите git clone https://github.com/ivsbex/website

Türk
Ñetu ínformacuu "file://ŝovsem"
Prŷam neţu: file:///sdcard/Download/website/main.html
nea ñetu
Error, Türks